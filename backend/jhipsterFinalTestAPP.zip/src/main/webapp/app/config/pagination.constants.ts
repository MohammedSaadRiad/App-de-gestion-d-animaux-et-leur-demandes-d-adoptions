export const TOTAL_COUNT_RESPONSE_HEADER = 'X-Total-Count';
export const PAGE_HEADER = 'page';
export const ITEMS_PER_PAGE = 20;
