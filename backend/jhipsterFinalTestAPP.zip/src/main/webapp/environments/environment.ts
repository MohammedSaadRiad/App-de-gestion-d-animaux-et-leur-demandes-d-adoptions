export const environment = {
  VERSION: __VERSION__,
  DEBUG_INFO_ENABLED: false,
};
