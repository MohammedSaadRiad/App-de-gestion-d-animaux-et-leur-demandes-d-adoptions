import('./bootstrap').catch((err: unknown) => console.error(err));
