/**
 * Application root.
 */
package com.mycompany.myapp;
